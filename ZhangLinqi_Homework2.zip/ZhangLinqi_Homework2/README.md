作业2：
完成了提高题，结果图片output.png