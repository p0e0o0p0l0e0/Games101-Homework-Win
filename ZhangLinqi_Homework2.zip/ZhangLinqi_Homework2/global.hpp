//
// Created by LEI XU on 4/9/19.
//

#ifndef RASTERIZER_GLOBAL_H
#define RASTERIZER_GLOBAL_H

//#define MY_PI 3.1415926
//#define TWO_PI (2.0* MY_PI)


#endif //RASTERIZER_GLOBAL_H
