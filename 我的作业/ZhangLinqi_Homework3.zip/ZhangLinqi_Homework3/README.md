作业3：
1 7项都完成
2 各函数实现：
1）main.cpp phong_fragment_shader(...)：Blinn-Phong光照模型
2）main.cpp texture_fragment_shader(...)：纹理着色
3）main.cpp bump_fragment_shader(...)：用凹凸贴图移动法线，着色用法线值
4）main.cpp displacement_fragment_shader(...)：用凹凸贴图重新计算点的坐标和法线
5）rasterizer.cpp rasterize_triangle(...)：实现颜色、法向量、纹理坐标的插值，和观察空间中点的坐标。
6）Texture.hpp getColorBilinear(...)：取出纹理上离目标点最近的纹素进行双线性插值获取最终颜色。

问题：bump和displacement着色都和作业原图有些差距，没查出来原因，请老师帮忙看一下。