作业5：已完成。
提交结果图/images/binary.ppm。

Render.cpp中的Render(): 
    先将屏幕空间的坐标转换到[-1, 1]的标准化范围，再通过scale和imageAspectRatio恢复到在z=-1处的近平面，即得到每个像素点对应近平面的世界坐标，再和eye_pos相减计算射线方向。
Triangle.hpp中的rayTriangleIntersect()：
    通过MT算法计算得到tnear和u和v，再判断是否满足MT算法的条件，即可判断射线是否与三角形相交。