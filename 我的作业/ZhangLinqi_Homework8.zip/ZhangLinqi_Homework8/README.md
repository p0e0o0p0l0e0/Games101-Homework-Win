作业8：
1 完成了作业的所有项
2 代码修改：质点数修改为32个
1）在Rope的构造函数中添加了质点和弹簧，并设置pinned为true的质点
2）在simulateEuler中实现了显示欧拉法和半隐式欧拉法，并添加了阻尼系数
3）在simulateVerlet中实现了Verlet法，并添加了阻尼系数。
3 运行结果在images文件夹中